package net.hb.hotelMVC;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.hb.common.HotelDAO;
import net.hb.common.HotelDTO;



@WebServlet("/roombookInsert.do")
public class roomBookInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}//end

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}//end

	public void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out=response.getWriter();
		out.println("<font size=7 color=blue><b>PreEditController.java </b></font><p>");
		System.out.println("PreEditController.java ");
		out.println("<img src=images/gguri.png width=500 height=300> <p>");
			
		HttpSession session=request.getSession();
		
		
		String grade=request.getParameter("grade");
		String id=(String)session.getAttribute("userid");
		String name=request.getParameter("name");
		int chin=Integer.parseInt(request.getParameter("chin"));
		int chout=Integer.parseInt(request.getParameter("chout"));
		HotelDAO dao=new HotelDAO();
		HotelDTO dto=new HotelDTO();
		dto.setGrade(grade);
		dto.setId(id);
		dto.setName(name);
		dto.setChin(chin);
		dto.setChout(chout);
		dao.roomBookInsert(dto);
		
		
		response.sendRedirect("roomList.do");
	}//end
}//roomBookInsertController class END











