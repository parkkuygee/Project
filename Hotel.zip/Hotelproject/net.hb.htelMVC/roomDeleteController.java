package net.hb.hotelMVC;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.hb.common.HotelDAO;




@WebServlet("/roomDelete.do")
public class roomDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}//end

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}//end

	public void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out=response.getWriter();
		out.println("<font size=7 color=blue><b>DeleteController.java </b></font><p>");
		System.out.println("DeleteController.java ");
		out.println("<img src=images/hydran.png width=500 height=300> <p>");
			
		String data=request.getParameter("grade");
		System.out.println("������Ʈ�� Gidx="+data);
		HotelDAO dao=new HotelDAO();
		dao.roomDelete(data);//���������ʹ� ���ϰ��� ���� �ʿ䰡����
		response.sendRedirect("roomList.do");
	}//end
}//DeleteController class END








