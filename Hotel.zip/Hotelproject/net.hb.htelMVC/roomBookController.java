package net.hb.hotelMVC;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.hb.common.HotelDAO;
import net.hb.common.HotelDTO;




@WebServlet("/roomBook.do")
public class roomBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}//end

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}//end

	public void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
			
		String data=request.getParameter("grade");
		HotelDAO dao=new HotelDAO();
		
		HotelDTO dto=dao.roomDetail(data);
		
		HttpSession session=request.getSession();
		session.setAttribute("admin", 1);
		session.setAttribute("userid", "ajxx733");
		request.setAttribute("dto", dto);
		RequestDispatcher dis=request.getRequestDispatcher("roomBook.jsp?grade="+data);
		dis.forward(request, response);
	}//end
}//class END









