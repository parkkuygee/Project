package net.hb.common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import net.hb.common.DB;

public class HotelBookDAO {
	private Connection CN;
	private PreparedStatement PST;
	private Statement ST;
	private ResultSet RS;
	String msg;
	
	public HotelBookDAO() {
		 CN=DB.getConnection();
	}
	
	public void bookInsert(HotelBookDTO dto) {
		msg="insert into hbook values(?,hbook_seq.nextval,?,?,?,?)";
		try {
			PST=CN.prepareStatement(msg);
			  PST.setInt(1, dto.getRnum());
			  PST.setString(2, dto.getId());
			  PST.setString(3, dto.getName());
			  PST.setString(4, dto.getChin());
			  PST.setString(5, dto.getChout());
			PST.executeUpdate();
			System.out.println("bookInsert() ����");
		}catch(Exception e) {System.out.println("bookInsert() ����"+e);}
	}

	public HotelBookDTO bookSelect(String id) {
		HotelBookDTO dto=new HotelBookDTO();
		try {
			msg="select * from hbook where id="+id;
			ST=CN.createStatement();
			RS=ST.executeQuery(msg);
			RS.next();
			dto.setBnum(RS.getInt("bnum"));
			dto.setName(RS.getString("name"));
			dto.setChin(RS.getString("chin"));
			dto.setChout(RS.getString("chout"));
			ST.execute(msg);
			System.out.println("bookSelect() ����");
		}catch (Exception e) {System.out.println("bookSelect() ����"+e);}
		return dto;
	}
	
	public void bookDelete(int bnum) {
		try {
			 msg="delete from hbook where bnum="+bnum ;
			 ST=CN.createStatement();
			 ST.executeUpdate(msg);	 
			 System.out.println("bookDelete() ���� ");
		 }catch(Exception ex) {System.out.println("bookDelete() ���� "+ex); }
	}
		
	public int bookRnum(String grade, String In, String Out) {
		int[] rnums=new int[5]; 
		int rnum=0;
		int IN=Integer.parseInt(In);
		int OUT=Integer.parseInt(Out);
		try {
			msg="select rnum from room where grade="+grade;
			ST=CN.createStatement();
			RS=ST.executeQuery(msg);
			int i=0;
			while(RS.next()==true) {rnums[i]=RS.getInt("rnum"); i++;}
			
		  for(int data : rnums) {System.out.println(data);}
		
		  for(i=0; i<5; i++) {
				msg="select * from hbook where rnum="+rnums[i];
				ST=CN.createStatement();
				RS=ST.executeQuery(msg);
				if(RS.next()==true) { //����� �� ��¥ ��
					if(IN>=Integer.parseInt(RS.getString("chout"))||OUT<=Integer.parseInt(RS.getString("chin"))){ //���� ����
						rnum=rnums[i];
					}else continue; //���� ���ȣ
				}else rnum=rnums[i]; //����ȵ� ��
			}//for
		  System.out.println(rnum); 
		}catch (Exception e) {System.out.println("bookRnum() ���� "+e); }
		return rnum; //rnum���� 0�̸� ����Ұ���(�ȳ�â)
	}
	
}
