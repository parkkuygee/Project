package net.hb.common;

import java.util.ArrayList;
import java.util.Random;

import org.apache.catalina.connector.Response;

public class HotelDAO extends GlobalVariable {
	
	public HotelDAO() {
		CN=DB.getConnection();
	}
	
	public int roomCount() {
		int count=0;
		try {
			msg="select count(*) as cnt from intro";
      ST=CN.createStatement();
      RS=ST.executeQuery(msg);
      if(RS.next()==true) {
     	 count=RS.getInt("cnt");
      }
		} catch (Exception e) {System.out.println("count����");	}
		return count;
	}
	
	public void roomDelete(String data) {
		try {
			msg="delete from intro where grade= '"+data+"'";
			ST=CN.createStatement();
			ST.executeUpdate(msg);
			
		} catch (Exception e) {System.out.println("delete����");		}
	}
	
	public void roomInsert(HotelDTO dto ) {
		try {
			msg="insert into intro values(?, ?, ?, ?, ?)";
			PST=CN.prepareStatement(msg);
			PST.setString(1, dto.getGrade());
			PST.setString(2, dto.getImage());
			PST.setString(3, dto.getContent());
			PST.setInt(4, dto.getPnum());
			PST.setInt(5, dto.getPrice());
			PST.executeUpdate();
		} catch (Exception e) { System.out.println("insert����");	}
		
	}
	
	public void roomUpdate(HotelDTO dto) {
		try {
			if(dto.getImage()!=null) {
			msg="update intro set image=?, content=?, pnum=?, price=? where grade=?";
			PST=CN.prepareStatement(msg);
			
			PST.setString(1, dto.getImage());
			PST.setString(2, dto.getContent());
			PST.setInt(3, dto.getPnum());
			PST.setInt(4, dto.getPrice());
			PST.setString(5, dto.getGrade());
			PST.executeUpdate();
			}else {
			msg="update intro set content=?, pnum=?, price=? where grade=?";
			PST=CN.prepareStatement(msg);
			
			PST.setString(1, dto.getContent());
			PST.setInt(2, dto.getPnum());
			PST.setInt(3, dto.getPrice());
			PST.setString(4, dto.getGrade());
			PST.executeUpdate();
			}
		} catch (Exception e) {System.out.println("update ����");		}
	}
	
	public ArrayList<HotelDTO> roomSelect(){
		ArrayList<HotelDTO> list = new ArrayList<HotelDTO>();
		try {
			msg="select rownum rn, p.*  from intro p ";
			ST=CN.createStatement();
			RS=ST.executeQuery(msg);
			while(RS.next()==true) {
				HotelDTO dto=new HotelDTO();
				dto.setRn(RS.getInt("rn"));
				dto.setGrade(RS.getString("grade"));
				dto.setImage(RS.getString("image"));
				dto.setContent(RS.getString("content"));
				dto.setPnum(RS.getInt("pnum"));
				dto.setPrice(RS.getInt("price"));
				list.add(dto);
			}
		} catch (Exception e) {System.out.println("select ����"); 		}
		return list;
	}
	
	public HotelDTO roomDetail(String data) {
		HotelDTO dto=new HotelDTO();
		try {
			msg="select * from intro where grade='"+data+"'";
			ST=CN.createStatement();
			RS=ST.executeQuery(msg);
			if(RS.next()==true) { 
				dto.setGrade(RS.getString("grade"));
				dto.setImage(RS.getString("image"));
				dto.setContent(RS.getString("content"));
				dto.setPnum(RS.getInt("pnum"));
				dto.setPrice(RS.getInt("price"));
			}
		} catch (Exception e) {System.out.println("detail ����");		}
		
		return dto;
	}
	
	public int roomBookSelect(HotelDTO dto) {
			int[] rnums=new int[5]; 
			int rnum=0;
			int IN=dto.getChin();
			int OUT=dto.getChout();
			int i=0;
			try {
//				msg="select rnum from room where grade="+dto.getGrade();
//				ST=CN.createStatement();
//				RS=ST.executeQuery(msg);
//				int i=0;
//				while(RS.next()==true) {rnums[i]=RS.getInt("rnum"); i++;}
				
					for(i=101; i<106; i++) {
						
					 msg="select * from hbook where rnum="+i;
					 ST=CN.createStatement();
					 RS=ST.executeQuery(msg);
					 while(RS.next()==true) {
						 
					if(dto.getChin()==RS.getInt("chin") ) {
						System.out.println("����");
					 }else {
							 System.out.println("����");
							 break;
						 }
					 	 break;
					 	}//while end
					
					}//for end
					 
		} catch (Exception e) {	System.out.println("bookselect����"+e);	}
		return i;
	}
	
	public void roomBookInsert(HotelDTO dto) {
		 try {
			 int rnum=roomBookSelect(dto);
			 msg="insert into hbook values(?, hbook_seq.nextval, ?, ?, ?, ?)";
			 PST=CN.prepareStatement(msg);
			 PST.setInt(1, rnum);
			 PST.setString(2, dto.getId());
			 PST.setString(3, dto.getName());
			 PST.setInt(4, dto.getChin());
			 PST.setInt(5, dto.getChout());
			 PST.executeUpdate();
			 
		} catch (Exception e) {System.out.println("bookinsert����");}
	}
	
}
