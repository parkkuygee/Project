package net.hb.common;

public class HotelBookDTO {
	int rnum; //���ȣ
	int bnum; //�����ȣ
  String id;
  String name;
  String chin;
  String chout;
  
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	public int getBnum() {
		return bnum;
	}
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChin() {
		return chin;
	}
	public void setChin(String chin) {
		this.chin = chin;
	}
	public String getChout() {
		return chout;
	}
	public void setChout(String chout) {
		this.chout = chout;
	}
  
  
}
